package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class WeightLossViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: WeightLossRepository

    val userProfile: StateFlow<UserProfileEntity?>
    val allDailyProgress: StateFlow<List<DailyProgressEntity>>
    val allWeightLogs: StateFlow<List<WeightLogEntity>>

    init {
        val database = WeightLossDatabase.getDatabase(application)
        repository = WeightLossRepository(database)
        userProfile = repository.userProfile.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )
        allDailyProgress = repository.allDailyProgress.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
        allWeightLogs = repository.allWeightLogs.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    // Calculates health budgets and creates user profile
    fun setupUserProfile(
        startingWeight: Double,
        height: Double,
        age: Int,
        gender: String, // "ذكر" or "أنثى"
        activityLevel: String // "خامل", "متوسط", "نشط جداً"
    ) {
        viewModelScope.launch {
            // Apply Mifflin-St Jeor Equation to estimate BMR
            val bmr = if (gender == "ذكر") {
                (10.0 * startingWeight) + (6.25 * height) - (5.0 * age) + 5.0
            } else {
                (10.0 * startingWeight) + (6.25 * height) - (5.0 * age) - 161.0
            }

            // Estimate TDEE based on activity Level
            val activeMultiplier = when (activityLevel) {
                "خامل" -> 1.2
                "متوسط" -> 1.55
                "نشط جداً" -> 1.725
                else -> 1.375
            }
            val tdee = bmr * activeMultiplier

            // Goal is to lose 4 kg in 30 days which requires roughly a 1000 kcal daily deficit
            // Set safety minimums for calorie budgets: 1500 for men, 1200 for women
            val minimumSafetyIntake = if (gender == "ذكر") 1500 else 1200
            val targetCalMeal = (tdee - 1000.0).toInt().coerceAtLeast(minimumSafetyIntake)

            // Dynamic exercise goals: if we can't restrict calories further, prescribe slightly more exercise calories
            val targetBurn = if (tdee - targetCalMeal < 1000) {
                250 // Compensate via active target
            } else {
                200
            }

            val profile = UserProfileEntity(
                startingWeight = startingWeight,
                currentWeight = startingWeight,
                height = height,
                age = age,
                gender = gender,
                activityLevel = activityLevel,
                targetWeight = (startingWeight - 4.0).coerceAtLeast(30.0),
                dailyCalorieTarget = targetCalMeal,
                dailyCalorieBurnTarget = targetBurn
            )

            // Reset and insert new data
            repository.resetAllData()
            repository.insertUserProfile(profile)
            repository.initializeDefault30Days()

            // Insert initial history log
            repository.insertWeightLog(
                WeightLogEntity(
                    date = "بداية الرحلة",
                    weight = startingWeight
                )
            )
        }
    }

    // Records selection of an Iraqi meal for the current day
    fun selectMeal(day: Int, mealType: String, optionIdx: Int) {
        viewModelScope.launch {
            val dayProgress = repository.getDailyProgressDirect(day) ?: DailyProgressEntity(day = day)

            var bIdx = dayProgress.breakfastChoiceIdx
            var lIdx = dayProgress.lunchChoiceIdx
            var dIdx = dayProgress.dinnerChoiceIdx
            var sIdx = dayProgress.snackChoiceIdx

            when (mealType) {
                "BREAKFAST" -> bIdx = optionIdx
                "LUNCH" -> lIdx = optionIdx
                "DINNER" -> dIdx = optionIdx
                "SNACK" -> sIdx = optionIdx
            }

            // Calculate total calories eaten based on selections
            var eatenCalories = 0
            if (bIdx >= 0) eatenCalories += DietAndWorkoutProgram.masterBreakfastOptions.find { it.id == bIdx }?.calories ?: 0
            if (lIdx >= 0) eatenCalories += DietAndWorkoutProgram.masterLunchOptions.find { it.id == lIdx }?.calories ?: 0
            if (dIdx >= 0) eatenCalories += DietAndWorkoutProgram.masterDinnerOptions.find { it.id == dIdx }?.calories ?: 0
            if (sIdx >= 0) eatenCalories += DietAndWorkoutProgram.masterSnackOptions.find { it.id == sIdx }?.calories ?: 0

            val updated = dayProgress.copy(
                breakfastChoiceIdx = bIdx,
                lunchChoiceIdx = lIdx,
                dinnerChoiceIdx = dIdx,
                snackChoiceIdx = sIdx,
                caloriesEaten = eatenCalories
            )
            repository.insertDailyProgress(updated)
        }
    }

    // Deselects a meal
    fun deselectMeal(day: Int, mealType: String) {
        selectMeal(day, mealType, -1)
    }

    // Toggles a daily home physical workout and updates total active energy burned
    fun toggleExercise(day: Int, exerciseId: Int) {
        viewModelScope.launch {
            val dayProgress = repository.getDailyProgressDirect(day) ?: DailyProgressEntity(day = day)
            val currentList = if (dayProgress.exerciseDoneIds.isEmpty()) {
                mutableListOf()
            } else {
                dayProgress.exerciseDoneIds.split(",")
                    .mapNotNull { it.toIntOrNull() }
                    .toMutableList()
            }

            if (currentList.contains(exerciseId)) {
                currentList.remove(exerciseId)
            } else {
                currentList.add(exerciseId)
            }

            val newListString = currentList.joinToString(",")

            // Re-calculate calorie burns to sync
            val availableExercises = DietAndWorkoutProgram.getExercisesForDay(day)
            var totalBurned = 0
            currentList.forEach { id ->
                val ex = availableExercises.find { it.id == id }
                if (ex != null) {
                    totalBurned += ex.caloriesBurned
                }
            }

            val updated = dayProgress.copy(
                exerciseDoneIds = newListString,
                caloriesBurned = totalBurned
            )
            repository.insertDailyProgress(updated)
        }
    }

    // Increments or decrements water intake
    fun changeWaterCups(day: Int, increment: Int) {
        viewModelScope.launch {
            val dayProgress = repository.getDailyProgressDirect(day) ?: DailyProgressEntity(day = day)
            val newCups = (dayProgress.waterCups + increment).coerceAtLeast(0)
            val updated = dayProgress.copy(waterCups = newCups)
            repository.insertDailyProgress(updated)
        }
    }

    // Records current scale weight for the current day of the journey
    fun logWeightForDay(day: Int, weight: Double) {
        if (weight <= 0) return
        viewModelScope.launch {
            val dayProgress = repository.getDailyProgressDirect(day) ?: DailyProgressEntity(day = day)
            val updated = dayProgress.copy(weightLogged = weight)
            repository.insertDailyProgress(updated)

            // Save to history graph logs with proper label
            repository.insertWeightLog(
                WeightLogEntity(
                    date = "اليوم $day",
                    weight = weight
                )
            )
        }
    }

    // Adds a manual weight log
    fun addManualWeightLog(label: String, weight: Double) {
        if (weight <= 0 || label.isEmpty()) return
        viewModelScope.launch {
            repository.insertWeightLog(
                WeightLogEntity(
                    date = label,
                    weight = weight
                )
            )
        }
    }

    // Deletes an individual weight log
    fun deleteWeightLog(log: WeightLogEntity) {
        viewModelScope.launch {
            repository.deleteWeightLog(log)
        }
    }

    // Toggles current day marked as fully finished (Completed)
    fun toggleDayCompleted(day: Int) {
        viewModelScope.launch {
            val dayProgress = repository.getDailyProgressDirect(day) ?: DailyProgressEntity(day = day)
            val updated = dayProgress.copy(isCompleted = !dayProgress.isCompleted)
            repository.insertDailyProgress(updated)
        }
    }

    // Resets weight loss logs and starts clean
    fun resetJourney() {
        viewModelScope.launch {
            repository.resetAllData()
            // Profile is set to null in data state so onboarding triggers again
            val defaultEmptyProfile = UserProfileEntity(
                id = 1,
                startingWeight = 0.0,
                currentWeight = 0.0,
                height = 0.0,
                age = 0,
                gender = "ذكر",
                activityLevel = "خامل",
                targetWeight = 0.0,
                dailyCalorieTarget = 0,
                dailyCalorieBurnTarget = 0
            )
            repository.insertUserProfile(defaultEmptyProfile)
        }
    }
}
