package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldSecondary,
    onPrimary = Color.Black,
    primaryContainer = EmeraldPrimary,
    onPrimaryContainer = Color.White,
    secondary = EmeraldSecondary,
    onSecondary = Color.Black,
    tertiary = EmeraldTertiary,
    onTertiary = Color.Black,
    background = MidnightDarkBg,
    onBackground = TextWhite,
    surface = MidnightSurface,
    onSurface = TextWhite,
    surfaceVariant = MidnightSurfaceVariant,
    onSurfaceVariant = TextGreenGray
)

private val LightColorScheme = lightColorScheme(
    primary = LightEmeraldPrimary,
    onPrimary = Color.White,
    primaryContainer = LightBg,
    onPrimaryContainer = LightEmeraldPrimary,
    secondary = LightEmeraldSecondary,
    onSecondary = Color.White,
    tertiary = EmeraldTertiary,
    onTertiary = Color.Black,
    background = LightBg,
    onBackground = TextDark,
    surface = LightSurface,
    onSurface = TextDark,
    surfaceVariant = Color(0xFFE1ECE4),
    onSurfaceVariant = TextGray
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // We force custom themed scheme for consistent premium branding
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
