package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val id: Int = 1,
    val startingWeight: Double,
    val currentWeight: Double,
    val height: Double,
    val age: Int,
    val gender: String, // "ذكر" or "أنثى"
    val activityLevel: String, // "خامل" or "متوسط" or "نشط جداً"
    val targetWeight: Double, // Starting Weight - 4
    val dailyCalorieTarget: Int,
    val dailyCalorieBurnTarget: Int
)

@Entity(tableName = "daily_progress")
data class DailyProgressEntity(
    @PrimaryKey val day: Int, // Day 1 to 30
    val caloriesEaten: Int = 0,
    val caloriesBurned: Int = 0,
    val breakfastChoiceIdx: Int = -1, // -1 means not chosen/eaten yet
    val lunchChoiceIdx: Int = -1,
    val dinnerChoiceIdx: Int = -1,
    val snackChoiceIdx: Int = -1,
    val exerciseDoneIds: String = "", // e.g. "0,1"
    val waterCups: Int = 0,
    val weightLogged: Double = 0.0,
    val isCompleted: Boolean = false
)

@Entity(tableName = "weight_log")
data class WeightLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String, // "YYYY-MM-DD"
    val weight: Double
)

// Data class representation for Meal option
data class MealOption(
    val id: Int,
    val name: String,
    val description: String,
    val calories: Int
)

// Data class representation for Exercise option
data class ExerciseOption(
    val id: Int,
    val name: String,
    val description: String,
    val durationMinutes: Int,
    val caloriesBurned: Int
)

object DietAndWorkoutProgram {

    // Iraqi healthy breakfast options master pool (خيارات الريوك - الفطور)
    val masterBreakfastOptions = listOf(
        MealOption(0, "بيضتين مسلوقة مع خبز شعير عراقي", "بيض سلق عدد 2 مع نصف رغيف خبز شعير وخيار وطماطم مع شاي مهيل بدون سكر", 250),
        MealOption(1, "بيض عيون بزيت زيتون خفيف", "بيضتين مقلية بملعقة زيت زيتون خفيفة، مع ربع قرص خبز تنور حار وخضرة مشكلة", 280),
        MealOption(2, "جبن عرب دايت مع كرفس ورشاد", "جبن عرب قليل الملح والدسم (70 غم) مع نصف رغيف خبز شعير، وشاي بالنعناع والهيل", 220),
        MealOption(3, "مخلمة لحم بقر دايت وخضار", "لحم عجل مفروم ناعم بدون دهن (50 غم)، بصل، طماطم، طرشانة مطبوخة رشاً بالزيت مع بيضة سلق", 270),
        MealOption(4, "شوفان بالحليب والتمر العراقي", "4 ملاعق شوفان مطبوخة بحليب قليل الدسم ومحلاة بحبتين تمر خستاوي عراقي ورشة دارسين", 260),
        MealOption(5, "فول بالخلطة العراقية وزيت الزيتون", "فول مدمس بصلصة الكمون والثوم والليمون مع ملعقة زيت زيتون ونصف خبز شعير وجرجير", 240),
        MealOption(6, "بيض بالبسطرمة الدايت (بدون دهن)", "بسطرمة عراقية خالية من الشحم مع بيضتين ومسحة خفيفة من الزيت مع خبز نخالة", 290),
        MealOption(7, "كيمر فطور دايت مخفف", "كيمر دايت محضر من حليب منزوع الدسم مضاف له ملعقة عسل سدر طبيعي وربع خبز أسمر مع جرجير ورشاد", 190),
        MealOption(8, "بيض مخفوق بالفطر والبقدونس", "بيضتين مخفوقة بالفطر الطازج والكمون والليمون وبقدونس مفروم مع خبز دايت", 230),
        MealOption(9, "جبنة فيتا لايت بالزعتر والزيتون", "جبن فيتا لايت مع زعتر بري وزيتون وعصير ليمون ونصف خلية خبز شعير", 200),
        MealOption(10, "روب عراقي بالفاكهة وبذور الكتان", "كوب زبادي (روب عراقي) مخفف مع فراولة أو تفاح ورشة بذور الكتان المحمصة ومحلى بستيفيا", 180),
        MealOption(11, "حمص بطحينة عراقي دايت", "حمص مسلوق ومطحون بطحينة خفيفة وعصير ليمون، مع نصف قرص خبز شعير وخيار", 260)
    )

    // Iraqi healthy lunch options master pool (خيارات الغداء)
    val masterLunchOptions = listOf(
        MealOption(0, "تمن وقيمة نجفية دايت", "تمن بسمتي مبزول ومحضر بدون زيت مضاف (6 ملاعق) مع مرق القيمة النجفية باللحم بدون شحم وبدون دهن مضاف وسلطة عراقية بالليمون", 400),
        MealOption(1, "سمك مسكوف عراقي بالفرن مع تمن أحمر", "سمكة بني أو قطان مسكوفة بطريقة صحية متبلة بنومي بصرة وثوم (200 غم) + 5 ملاعق تمن أحمر دايت + زلاطة لهانة", 440),
        MealOption(2, "دولمة عراقية دايت رائعة", "6 حبات دولمة مشكلة (سلق، شجر، باذنجان، بصل) محشوة بلحم العجل الخالي من الدهن والرز البني وخضار مضاعف مع دبس رمان طبيعي", 380),
        MealOption(3, "تشريب دجاج أصفر دايت", "صدر دجاج مسلوق بدون جلد غني بالبهارات الصفراء وليمون دجلة ونومي بصرة مع ربع قرص خبز شعير مثرود بالمرق منزوع الدسم", 410),
        MealOption(4, "مرقة بامية باللحم الخالي من الدهن والتمن", "مرقة بامية بالثوم الكثيف المطبوخة بلحم عجل بدون دهن تماماً مع 6 ملاعق تمن أبيض مسلوق وحلقات بصل مع كرفس ورشاد", 395),
        MealOption(5, "برغل بالطماطة عراقي مع كفتة مشوية", "كوب برغل عراقي مطبوخ بعصير الطماطم والبصل مع 3 قطع كفتة لحم عجل بالفرن وسلطة خيار بالليمون", 420),
        MealOption(6, "تشريب لحم أحمر ليموني دايت", "قطع لحم حمراء خالية تماماً من الدهون مسلوقة بالبهارات ونومي بصرة مع ثريد خبز شعير", 430),
        MealOption(7, "مرقة سبزي (سبانخ) عراقية مع تمن", "مرق سبانخ عراقي باللوبيا واللحم الهبر المطبوخ بدون زيت مع 6 ملاعق تمن بسمتي مسلوق وجرجير", 380),
        MealOption(8, "مرقة شجر (كوسا) بالدجاج والتمن", "شجر مطبوخ بالثوم والنعناع وصلصة طماطم خفيفة مع صدر دجاج مشوي و5 ملاعق تمن ابيض", 360),
        MealOption(9, "مقلوبة باذنجان دايت مشوية", "باذنجان وطماطم وبصل مشوي بالفرن طبقات مرصوصة مع لحم مفروم وتمن بسمتي منزوع الزيت", 390),
        MealOption(10, "صدر دجاج بصلصة نومي بصرة حمراء", "صدر دجاج (200 غم) مطبوخ بصلصة الطماطم الحمراء ونومي بصرة والخل العراقي مع سلطة جرجير", 375),
        MealOption(11, "سمكة جري مشوية بالفرن بتتبيلة البصرة", "سمكة جري أو زبيدي متبلة بالثوم والكاري ونومي بصرة مغطاة بورق السلق ومسلوقة بالفرن", 420),
        MealOption(12, "كباب عروق طاوت دايت", "كباب طاوت مصنوع بلحم عجل وثريد بقدونس وبصل مخبوز في فرن حار مع سلطة مشكلة حمراء", 355),
        MealOption(13, "مطبق سمك عراقي لايت", "رز بسمتي بهيل وكاري مضاف فوقه سمك هامور مشوي بصلصة حامض خفيفة مع بصل مخمل", 430),
        MealOption(14, "شجر محشي باللحم والخضار بالفرن", "شجر محشي بلحم عجل مفروم وكرفس وطماطم من غير رز مطبوخ بمرق عصير الطماطم الطبيعي", 350)
    )

    // Iraqi healthy dinner options master pool (خيارات العشاء)
    val masterDinnerOptions = listOf(
        MealOption(0, "كباب دجاج مشوي بالبيت مع خبز شعير", "قطعتين (شيشين) كباب دجاج (صدور دجاج مفرومة كرفس وبصل)، بصل وطماطم مشوية مع ربع قرص خبز شعير", 310),
        MealOption(1, "خبز عروق دايت بالفرن", "قطعتين من خبز عروق محضر بطحين بر أسمر ولحم عجل منزوع الدهن مقطع ناعم وكثير من الكرفس والبصل والتوابل ومخبوز بالفرن", 260),
        MealOption(2, "شوربة عدس عراقية مع ليمون وجرجير", "كاسة كبيرة شوربة عدس عراقية دافئة ومطبوخة بالكمون والكركم بدون زيت زائد، تقدم مع ليمون حامض وحزمة جرجير", 185),
        MealOption(3, "عشاء منزلي خفيف (خاثر عراقي وجبن دايت)", "كوب لبن خاثر عراقي قليل الدسم ورشة نعناع، قطعة صغيرة جبن أبيض خفيف، خيار وطماطم مقطعة، ربع خبز نخالة", 210),
        MealOption(4, "تشريب باقلاء بالبيض المقلي دايت", "ربع قرص خبز أسمر مثرود بماء الباقلاء المسلوقة مع بطن بصل ونعناع وقليل من عصير الحامض مضاف بيضة مقلية بمسحة زيت زيتون", 290),
        MealOption(5, "شوربة ماش عراقية دافئة ومغذية", "ماش مسلوق ومطحون ببصل دايت مكرمل قليلاً وبدون زيوت مضافة تقدم مع ربع قرص خبز نخالة مقرمش بالفرن", 175),
        MealOption(6, "كفتة لحم عجل مشوية بالفرن", "3 قطع كفتة لحم عجل بالبقدونس والبصل مشوية طرية بالفرن وسلطة خيار بالزبادي", 250),
        MealOption(7, "سلطة البيض العراقي والبطاطس المسلوقة", "بيضة مسلوقة مقطعة مع نصف حبة بطاطا سلق ومعدنوس وزيت زيتون خفيف (ملعقة شاي)", 230),
        MealOption(8, "همبرغر منزلي صدر دجاج مشوي", "همبرغر معد بالبيت من صدور دجاج مشوية بصلصة جير ومقدم بخبز أسمر مع خس وطماطم وخردل", 280),
        MealOption(9, "روب عراقي بنعناع وبثوم دايت وفجل", "كوب زبادي خاثر طبيعي مخلوط مع ثوم ناعم ورشة نعناع يابس يقدم مع فجل أحمر وخيار", 150),
        MealOption(10, "عجة خضار عراقية بالفرن", "خليط من بيضتين مخفوقتين مع كرافس، بصل، جزر مفروم، بهارات مشكلة مخبوز بوعاء فخار بالفرن", 215),
        MealOption(11, "تكة لحم عجل مشوية على الفحم", "150 غم تكة لحم عجل خالية من اللية مشوية مع بصل وطماطم ونعناع طازج", 270)
    )

    // Iraqi healthy snack options master pool (خيارات السناك)
    val masterSnackOptions = listOf(
        MealOption(0, "تميرات خستاوي مع القهوة المرة", "3 حبات تمر خستاوي أو برحي لذيذ مع فنجان قهوة عربية حارة بالهيل", 90),
        MealOption(1, "رقي عراقي بارد بالفواكه", "شريحتين متوسطة رقي عراقي أحمر بارد منعش (كوبين مقطعة)", 80),
        MealOption(2, "رمان عراقي حامض مفلس", "نصف كوب من حبيبات الرمان العراقي الحامض الحلو المنعش", 70),
        MealOption(3, "فستق حلبي أو لوز محمص عراقي", "10 حبات من المكسرات المحمصة الطبيعية غير المملحة سناك رائع وصحي للشرب مع الشاي الأخضر", 100),
        MealOption(4, "شاي عراقي مهيل خفيف مع بسكت شعير", "استكان شاي عراقي مخدر مهيل مع حبتين بسكت شعير خالي من السكر المضاف", 110),
        MealOption(5, "تفاح أخضر عراقي مقطع برشة دارسين", "تفاحة خضراء متوسطة طازجة مقطعة شرائح مع رشة قليلة من الدارسين (القرفة) لتعزيز الحرق", 85),
        MealOption(6, "كرزات مشكلة خفيفة", "قبضة كرزات صغيرة (فستق، لوز، جوز) غير مملحة ومحمصة ببطء", 115),
        MealOption(7, "شجر عرانيس (ذرة مسلوقة)", "نصف عرنوص ذرة عراقي مسلوق بالماء مع رشة ليمون وسماق عراقي حاد", 95),
        MealOption(8, "شاي عراقي بالزنجيبل والنعناع مع حلقيم دايت", "استكان شاي مضاف له زنجبيل طازج ونعناع مع حبة تمر واحدة", 75),
        MealOption(9, "عنب عراقي بارد بلونين", "زبدية صغيرة من العنب العراقي الأخضر أو الأسود الحامض الحلو بعد وضعه بالمجمدة", 85),
        MealOption(10, "لب لبلبي عراقي حار وحامض", "كوب صغير لبلبي (حمص مسلوق ببهارات حارة وعصير نومي حامض) مغذي وغني بالألياف للشتاء والصيف", 120),
        MealOption(11, "حب رقي (بذور البطيخ) عراقي محمص", "ملعقتين طعام من حب الرقي المملح الخفيف المحمص سناك شعبي مسلٍ ومفيد", 90)
    )

    // Backwards compatibility list references
    val breakfastOptions = masterBreakfastOptions
    val lunchOptions = masterLunchOptions
    val dinnerOptions = masterDinnerOptions
    val snackOptions = masterSnackOptions

    // Dynamically retrieve breakfast options for a specific day (returns 5 options)
    fun getBreakfastOptionsForDay(day: Int): List<MealOption> {
        val size = masterBreakfastOptions.size
        if (size == 0) return emptyList()
        val list = mutableListOf<MealOption>()
        val offsets = listOf(0, 2, 4, 6, 8)
        for (offset in offsets) {
            val rawIdx = (day - 1 + offset) % size
            val idx = if (rawIdx < 0) rawIdx + size else rawIdx
            list.add(masterBreakfastOptions[idx])
        }
        return list.distinctBy { it.id }
    }

    // Dynamically retrieve lunch options for a specific day (returns 5 options)
    fun getLunchOptionsForDay(day: Int): List<MealOption> {
        val size = masterLunchOptions.size
        if (size == 0) return emptyList()
        val list = mutableListOf<MealOption>()
        val offsets = listOf(0, 3, 6, 9, 12)
        for (offset in offsets) {
            val rawIdx = (day - 1 + offset) % size
            val idx = if (rawIdx < 0) rawIdx + size else rawIdx
            list.add(masterLunchOptions[idx])
        }
        return list.distinctBy { it.id }
    }

    // Dynamically retrieve dinner options for a specific day (returns 5 options)
    fun getDinnerOptionsForDay(day: Int): List<MealOption> {
        val size = masterDinnerOptions.size
        if (size == 0) return emptyList()
        val list = mutableListOf<MealOption>()
        val offsets = listOf(0, 2, 4, 6, 8)
        for (offset in offsets) {
            val rawIdx = (day - 1 + offset) % size
            val idx = if (rawIdx < 0) rawIdx + size else rawIdx
            list.add(masterDinnerOptions[idx])
        }
        return list.distinctBy { it.id }
    }

    // Dynamically retrieve snack options for a specific day (returns 5 options)
    fun getSnackOptionsForDay(day: Int): List<MealOption> {
        val size = masterSnackOptions.size
        if (size == 0) return emptyList()
        val list = mutableListOf<MealOption>()
        val offsets = listOf(0, 2, 4, 6, 8)
        for (offset in offsets) {
            val rawIdx = (day - 1 + offset) % size
            val idx = if (rawIdx < 0) rawIdx + size else rawIdx
            list.add(masterSnackOptions[idx])
        }
        return list.distinctBy { it.id }
    }

    // Generates localized training plan for a specific day in the 30-day weight loss journey
    fun getExercisesForDay(day: Int): List<ExerciseOption> {
        val rawType = day % 4
        val type = if (rawType < 0) rawType + 4 else rawType
        return when (type) {
            1 -> listOf(
                ExerciseOption(0, "المشي السريع بالكورنيش", "مشي بخطوات سريعة ومنتظمة على الكورنيش أو المتنزه لرفع نبضات القلب", 40, 200),
                ExerciseOption(1, "صعود ونزول الدرج بالمنزل", "تمارين صعود ونزول الدرج بانتظام لتقوية عضلات الفخذ والمؤخرة", 15, 120),
                ExerciseOption(2, "تمارين تمدد وإطالة", "تمارين لزيادة المرونة وتهدئة العضلات بعد التمرين", 10, 30)
            )
            2 -> listOf(
                ExerciseOption(0, "تمارين سويدية منزلية حارقة", "تمارين جمباز وسويدية منزلية (نط الحبل الافتراضي، قفز جاك، سكوات)", 30, 220),
                ExerciseOption(1, "تمارين لشد البطن والخواصر", "تمارين بلانك ومعدة منزلية لشد منطقة الكرش وتخفيف الخواصر", 15, 90)
            )
            3 -> listOf(
                ExerciseOption(0, "تمارين المقاومة بقناني المياه", "استخدام قناني ماء متساوية الحجم كأوزان بديلة للدمبلز لتمارين الباي والتراي والأكتاف", 35, 160),
                ExerciseOption(1, "مشي سريع داخل البيت أو فناء الدار", "مشي مستمر بخطى سريعة داخل فناء الدار لزيادة عدد الخطوات اليومية", 20, 100)
            )
            else -> listOf(
                ExerciseOption(0, "كارديو مكثّف (HIIT) دايت", "تمارين كارديو عالية الكثافة مع فترات راحة قصيرة لحرق الدهون بأقصى سرعة بالمنزل", 25, 230),
                ExerciseOption(1, "شد وتثبيت الجسم (بلانك وجسور)", "تمارين البلانك وجسر الأرداف لتقوية عضلات الظهر والجذع والبطن", 15, 70)
            )
        }
    }
}
