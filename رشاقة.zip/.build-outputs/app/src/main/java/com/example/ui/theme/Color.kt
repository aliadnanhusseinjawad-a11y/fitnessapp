package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Healthy Emerald & Golden Mesopotamian Sun Palette
val EmeraldPrimary = Color(0xFF2E7D32) // Deep healthy green (النخيل العراقي)
val EmeraldSecondary = Color(0xFF00C853) // Bright active neon mint
val EmeraldTertiary = Color(0xFFFFA000) // Solar Gold (شمس العراق)

// Luxurious Dark Theme (Preferred for the high-end premium interface)
val MidnightDarkBg = Color(0xFF0F1912) // Deep elegant palmgrove midnight
val MidnightSurface = Color(0xFF1A2A1E) // Rich dark-sage surface card
val MidnightSurfaceVariant = Color(0xFF253B2B) // Slightly lighter card border
val TextWhite = Color(0xFFFAFAFA)
val TextGreenGray = Color(0xFFB9C5BC)

// Light Mode Fallback
val LightEmeraldPrimary = Color(0xFF1B5E20)
val LightEmeraldSecondary = Color(0xFF2E7D32)
val LightBg = Color(0xFFF4FAF6)
val LightSurface = Color(0xFFFFFFFF)
val TextDark = Color(0xFF1E2721)
val TextGray = Color(0xFF5A685F)
